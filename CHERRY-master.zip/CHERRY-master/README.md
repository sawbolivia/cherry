
 <div id="readme" class="readme blob instapaper_body">
    <article class="markdown-body entry-content" itemprop="text"><h1><a id="user-content-CherryKodi-CHERRY -addons-repository" class="anchor" aria-hidden="true" href="#CHERRY TEAM -addons-repository"><svg class="octicon octicon-link" viewBox="0 0 16 16" version="1.1" width="16" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M4 9h1v1H4c-1.5 0-3-1.69-3-3.5S2.55 3 4 3h4c1.45 0 3 1.69 3 3.5 0 1.41-.91 2.72-2 3.25V8.59c.58-.45 1-1.27 1-2.09C10 5.22 8.98 4 8 4H4c-.98 0-2 1.22-2 2.5S3 9 4 9zm9-3h-1v1h1c1 0 2 1.22 2 2.5S13.98 12 13 12H9c-.98 0-2-1.22-2-2.5 0-.83.42-1.64 1-2.09V6.25c-1.09.53-2 1.84-2 3.25C6 11.31 7.55 13 9 13h4c1.45 0 3-1.69 3-3.5S14.5 6 13 6z"></path></svg></a>CherryKodi CHERRY Addons Repository</h1>
<p>Wszystkie dodatki zawarte w naszych repozytoriach nie są naszą własnością a treści w nich zawarte są własnością stron z których są pobrane. Repozytoium CherryTv oraz Dobre zostały połączone w jedno i nastąpiła zmiana nazwy na PTW Collection</p>
<h2><a id="user-content-zawartość-repozytoium" class="anchor" aria-hidden="true" href="#zawartość-repozytoium"><svg class="octicon octicon-link" viewBox="0 0 16 16" version="1.1" width="16" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M4 9h1v1H4c-1.5 0-3-1.69-3-3.5S2.55 3 4 3h4c1.45 0 3 1.69 3 3.5 0 1.41-.91 2.72-2 3.25V8.59c.58-.45 1-1.27 1-2.09C10 5.22 8.98 4 8 4H4c-.98 0-2 1.22-2 2.5S3 9 4 9zm9-3h-1v1h1c1 0 2 1.22 2 2.5S13.98 12 13 12H9c-.98 0-2-1.22-2-2.5 0-.83.42-1.64 1-2.09V6.25c-1.09.53-2 1.84-2 3.25C6 11.31 7.55 13 9 13h4c1.45 0 3-1.69 3-3.5S14.5 6 13 6z"></path></svg></a>Zawartość repozytorium</h2>
<table>
<thead>
<tr>
<th>Wtyczka</th>
<th>Nazwa</th>
<th>Wersja</th>
<th>Aktualizacja</th>
</tr>
</thead>
<tbody>
<tr>
<td><a target="_blank" href="https://raw.githubusercontent.com/CherryKodi/CHERRY/master/zips/repository.polishteam/icon.png"><img src="https://raw.githubusercontent.com/CherryKodi/CHERRY/master/zips/repository.polishteam/icon.png" width="48" style="max-width:100%;"></a></td>
<td>PolishTeam_Repo</td>
<td>0.1.3</td>
<td><a href="https://github.com/CherryKodi/CHERRY/raw/master/zips/repository.polishteam" 
rel="nofollow">2020-8-31</a></td>
</tr>
<tr>
<td><a target="_blank" href="https://raw.githubusercontent.com/CherryKodi/CHERRY/master/zips/repository.pltwcollection/icon.png"><img src="https://raw.githubusercontent.com/CherryKodi/CHERRY/master/zips/repository.pltwcollection/icon.png" width="48" style="max-width:100%;"></a></td>
<td>PTW COLLECTION</td>
<td>0.5</td>
<td><a href="https://github.com/CherryKodi/CHERRY/raw/master/zips/repository.pltwcollection" 
rel="nofollow">2020-8-31</a></td>
</tr>
<tr>
<td><a target="_blank" href="https://raw.githubusercontent.com/CherryKodi/CHERRY/master/zips/plugin.program.autocompletion/icon.png"><img src="https://raw.githubusercontent.com/CherryKodi/CHERRY/master/zips/plugin.program.autocompletion/icon.png" width="48" style="max-width:100%;"></a></td>
<td>Plugin Autocompletion</td>
<td>1.0.1.1</td>
<td><a href="https://github.com/CherryKodi/CHERRY/raw/master/zips/plugin.program.autocompletion" 
rel="nofollow">2020-8-31</a></td>
</tr>





  </div>
